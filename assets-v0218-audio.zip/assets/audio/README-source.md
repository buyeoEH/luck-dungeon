# LUCK Dungeon 오디오 팩 v1

판타지 신스·아르페지오 스타일의 직접 작곡/합성 음원입니다. 실제 오케스트라나 보컬 녹음은 사용하지 않았습니다. 기존 게임 소스에 적용된 버전이 아니라, 검토와 게임 연결을 위한 독립 오디오 팩입니다.

## 듣기

ZIP을 모두 압축 해제한 뒤 `들어보기.html`을 Chrome, Edge 또는 Firefox에서 여세요. 별도 설치·서버·인터넷 연결 없이 청음할 수 있습니다. Safari 등 OGG 지원이 제한된 환경에서는 MP3 미리듣기를 이용하세요.
`LUCK-audio-v1-preview.mp3`는 모든 파일을 순서대로 담은 미리듣기입니다. 음악은 곡당 약 9초씩 발췌했으며, 전체 곡은 audio 폴더에 있습니다. 미리듣기-순서.txt에서 시간을 확인할 수 있습니다.

## 음악 구성

- 시작 전: 88 BPM, 부드러운 벨과 패드, 기대감.
- 라운드 진행: 108 BPM, 가벼운 리듬과 반복 선율, 카드 선택에 맞춘 밀도.
- 전투 모션: 138 BPM, 브라스 계열 신스와 강한 리듬.
- 위험모드: 150 BPM, 빠른 저음 펄스와 경보 진입음.
- 무한모드: 144 BPM, 밝은 상행 선율과 빠른 아르페지오.

배경음은 마디 단위로 구성하고 잔향을 순환시킨 OGG 루프입니다. 효과음과 전환음은 WAV입니다. 모두 44.1 kHz / 스테레오이며 WAV는 16-bit입니다. 브라우저별 반복 전환 감각은 실제 게임 환경에서도 확인해 주세요.

## 이벤트 연결표

| 게임 이벤트 | 파일 ID |
|---|---|
| 시작 전 화면 | bgm_title |
| 손패 선택·구매·라운드 진행 | bgm_round |
| 전투 애니메이션 시작 | bgm_battle |
| 전투 애니메이션 끝 | bgm_round |
| 일반 공격 | sfx_attack_01 ~ 03 (무작위 하나) |
| 전체 공격 | sfx_aoe |
| 관통 공격 | sfx_pierce |
| 최대공격 소개 팝업 | sfx_max_intro |
| 최대공격 실제 타격 | sfx_max_hit |
| 위험모드 진입 | cue_danger_enter 이후 bgm_danger |
| 위험 해제 | bgm_round |
| 1~29라운드 정상 종료 | cue_round_clear |
| 30라운드 이전 패배·도전 종료 | cue_run_end |
| 30라운드 클리어 | cue_round30_clear |
| 무한모드 진입 | cue_infinite_enter 이후 bgm_infinite |

짧은 전투마다 BGM을 처음부터 바꾸면 산만할 수 있습니다. 실제 적용 시 전투가 아주 짧으면 bgm_round를 유지하고 효과음만 재생하는 선택도 가능합니다. 위험모드에서는 전투 BGM 전환보다 bgm_danger를 우선하세요. 소개음과 타격음의 간격은 애니메이션에 맞추고, 전환음 중복 재생은 게임 이벤트 쪽에서 막아 주세요.

## 연결 예제

```html
<script src="luck-audio.js"></script>
<script>
const sound = new LuckAudio('./'); // audio 폴더가 있는 패키지 루트 경로
// 브라우저 정책 때문에 첫 재생은 시작 버튼의 클릭/탭에서 호출합니다.
document.querySelector('#startButton').addEventListener('click', () => {
  sound.playBgm('bgm_round');
});
// 실제 게임의 공격 처리부에서 호출:
// sound.playSfx('sfx_attack'); // 일반 공격 3종 중 무작위
// sound.playSfx('sfx_aoe');
// sound.playSfx('sfx_pierce');
// sound.setBgmEnabled(false);
// sound.setSfxEnabled(false);
// sound.setVolumes(.45, .75);
</script>
```

기본 BGM 45%, 효과음 75%. 효과음 재생 중 BGM을 낮췄다가 복구합니다. 동시 효과음은 최대 8개로 제한합니다. 실제 게임의 이벤트 연결·설정 저장·장면별 전환 순서는 아직 적용하지 않았습니다. 이 파일은 API 연결 예제이며 현재 게임 파일을 수정하지 않습니다.

## 파일 목록

- `audio/bgm_title.ogg` — 시작 전 · 운명의 문 (43.636초)
- `audio/bgm_round.ogg` — 라운드 진행 · 선택의 불씨 (53.333초)
- `audio/bgm_battle.ogg` — 전투 모션 · 뒤집는 한 수 (41.739초)
- `audio/bgm_danger.ogg` — 위험모드 · 붉은 경계 (25.6초)
- `audio/bgm_infinite.ogg` — 무한모드 · 끝없는 계단 (40.0초)
- `audio/cue_round_clear.wav` — 일반 라운드 종료 · 작은 승리 (3.0초)
- `audio/cue_round30_clear.wav` — 30라운드 클리어 · 운명을 넘어서 (4.2초)
- `audio/cue_infinite_enter.wav` — 무한모드 진입 · 다시 열린 문 (3.6초)
- `audio/sfx_attack_01.wav` — 일반 공격 1 (0.62초)
- `audio/sfx_attack_02.wav` — 일반 공격 2 (0.62초)
- `audio/sfx_attack_03.wav` — 일반 공격 3 (0.62초)
- `audio/sfx_aoe.wav` — 전체 공격 · 확산 충격 (1.6초)
- `audio/sfx_pierce.wav` — 관통 공격 · 꿰뚫는 빛 (0.95초)
- `audio/sfx_max_intro.wav` — 최대공격 소개 · 힘의 집결 (2.1초)
- `audio/sfx_max_hit.wav` — 최대공격 타격 · 운명 파쇄 (1.7초)
- `audio/cue_danger_enter.wav` — 위험모드 진입 · 경계 경보 (2.4초)
- `audio/cue_run_end.wav` — 30라운드 전 도전 종료 · 남은 불씨 (3.3초)

## 미리듣기 순서

00:00  시작 전 · 운명의 문
00:09  라운드 진행 · 선택의 불씨
00:19  전투 모션 · 뒤집는 한 수
00:28  위험모드 · 붉은 경계
00:38  무한모드 · 끝없는 계단
00:48  일반 라운드 종료 · 작은 승리
00:51  30라운드 클리어 · 운명을 넘어서
00:56  무한모드 진입 · 다시 열린 문
01:00  일반 공격 1
01:02  일반 공격 2
01:03  일반 공격 3
01:04  전체 공격 · 확산 충격
01:07  관통 공격 · 꿰뚫는 빛
01:08  최대공격 소개 · 힘의 집결
01:11  최대공격 타격 · 운명 파쇄
01:13  위험모드 진입 · 경계 경보
01:16  30라운드 전 도전 종료 · 남은 불씨
